/* Esercitazione 2 - Esercizio 1 (Main) */
import java.io.*;
import java.util.*;



public class Main {


    public static void main(String argv[]) {  
        try {

            if (argv.length==0 || argv.length > 2){
                System.out.println("USAGE: java Main <filename> (<debug_level>)?");
                System.out.println("\n<debug_level> (optional) = 0 or 1 or 2");
                System.exit(0);
            }

            if (argv.length==2){                
                parser.debug_level = Integer.parseInt(argv[1]);
            }else{
                parser.debug_level = 0;
            }
            
            /* Istanzio lo scanner aprendo il file di ingresso argv[0] */
            Lexer l = new Lexer(new FileReader(argv[0]));
            /* Istanzio il parser */
            parser p = new parser(l);
            /* Avvio il parser */
            Object result = p.parse();      
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


