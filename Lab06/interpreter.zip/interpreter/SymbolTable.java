import java.util.*;



public class SymbolTable {
    private HashMap<String,Symbol> table;

    private class Symbol {
        private int type; /* 0-INT; 1-FLOAT */
        private int dim;
        private Object value;

        public Symbol(String type, int dimension) {
            if (type.equals("INT")) {
                this.type = 0;
                dim = dimension;
                value = new Integer[dim];
            }
            if (type.equals("DOUBLE")) {
                this.type = 1;
                dim = dimension;
                value = new Double[dim];
            }
        }

        public void changeValue(Integer value, int pos) {
            ((Integer[])this.value)[pos] = value;
        }
        public void changeValue(Double value, int pos) {
            ((Double[])this.value)[pos] = value;
        }

        public Integer getInteger(int pos){
            return ((Integer[])this.value)[pos];
        }
        public Double getDouble(int pos){
            return ((Double[])this.value)[pos];
        }

        public boolean isInteger() {
            if (type==0) return true;
            else return false;
        }
        public boolean isDouble() {
            if (type==1) return true;
            else return false;
        }
    }


    public SymbolTable() {
        table = new HashMap<String,Symbol>();
    }

            
    public void addSymbol(String name, String type, int dim){
        table.put(name, new Symbol(type, dim));
    }
    

    public void changeValue(String name, Integer value, int pos) {
        Symbol sym = table.get(name);
        sym.changeValue(value, pos);
        table.put(name, sym);
    }
    public void changeValue(String name, Double value, int pos) {
        Symbol sym = table.get(name);
        sym.changeValue(value, pos);
        table.put(name, sym);
    }

    public Integer getInteger(String name, int position) {
        Symbol sym = table.get(name);
        return sym.getInteger(position);
    }
    public Double getDouble(String name, int position) {
        Symbol sym = table.get(name);
        return sym.getDouble(position);
    }

    public boolean isInteger(String name) {
        Symbol sym = table.get(name);
        return sym.isInteger();
    }
    public boolean isDouble(String name) {
        Symbol sym = table.get(name);
        return sym.isDouble();
    }

}