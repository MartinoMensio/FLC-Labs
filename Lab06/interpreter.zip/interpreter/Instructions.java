import java.util.*;



public class Instructions {

    private static boolean isInteger(String num){
        try {
            Integer.parseInt(num);
        } catch (NumberFormatException ex) {
            return false;
        }
        return true;
    }
    private static boolean isDouble(String num){
        try {
            Double.parseDouble(num);
        } catch (NumberFormatException ex) {
            return false;
        }
        return true;
    }


    private class Result {
        int type;
        Object value;
    
        public Result(Integer value){
            type = 0;
            this.value = value;
        }
        public Result(Double value){
            type = 1;
            this.value = value;
        }
        public boolean isInteger() {
            if (type==0) return true;
            else return false;
        }
        public boolean isDouble() {
            if (type==1) return true;
            else return false;
        }
        public Integer getInteger(){
            return (Integer)value;
        }
        public Double getDouble(){
            return (Double)value;
        }

        public String toString(){
            return (String)value.toString();
        }

    }


    private class Instr {
        private String instr_type;

        private List arguments;

        public Instr(String inst, List argList){
            instr_type = inst;
            arguments = argList;
        }
        
        public String getInstruction() {
            return instr_type;
        }
        
        public List getArgList() {
            return arguments;
        }
    }



    private static String getVarNameFromArray(String var) {
        String[] tokens = var.split("[\\[\\]]");
        return tokens[0];
    }

    private static int getDimFromArray(String var) {
        String[] tokens = var.split("[\\[\\]]");
        
        if (tokens.length == 1) {
            return 0;
        }else{
            if (isInteger(tokens[1])){
                return Integer.parseInt(tokens[1]);
            }else{
                Integer dim = parser.symbolTable.getInteger(tokens[1], 0);
                return dim.intValue();
            }
 
        }
    }


    

    private int line;
    
    private List<Instr> instrList;
    
    public Instructions() {
        line = 0;
        instrList = new LinkedList<Instr>();
    }

    public void addInstruction(String instr, List argList) {
        instrList.add(new Instr(instr, argList));
        if (parser.debug_level>=1)
            System.out.println(line+" Istruz "+instr+" "+argList);
        line++;
    }

    public int getLine() {
        return line;
    }
    
    


    public void run(){
        int ip = 0;
        boolean keepOnRunning = true;
        Instr instruction;
        
        String instrName;
        List instrArgs;
        
        Result lastResult = new Result(new Integer(0));
        
        do{
            instruction = instrList.get(ip);
            ip++;
            
            instrName = instruction.getInstruction();
            instrArgs = instruction.getArgList();
            if (parser.debug_level>=2)
                System.out.print(ip+" "+instrName+" "+instrArgs+" ");
            
            if (instrName.equals("EVAL")) {
                lastResult = execEVAL(instrArgs);
                if (parser.debug_level>=2) System.out.println(" RES: "+lastResult);
            }else if (instrName.equals("ASS")) {
                /* Occorre ancora gestire il casting nel caso si assegni un 
                   double ad un integer */
                String varName = getVarNameFromArray((String)instrArgs.get(0));
                int dim = getDimFromArray((String)instrArgs.get(0));

                if (lastResult.isInteger()) {
                    parser.symbolTable.changeValue(varName, lastResult.getInteger(), dim);
                } else {
                    parser.symbolTable.changeValue(varName, lastResult.getDouble(), dim);        
                }
                if (parser.debug_level>=2) System.out.println(lastResult);

            }else if (instrName.equals("PRINT")) {
                String varName = getVarNameFromArray((String)instrArgs.get(0));
                int dim = getDimFromArray((String)instrArgs.get(0));

               if (parser.debug_level>=2) System.out.println();

                if (parser.symbolTable.isInteger(varName)) {
                    System.out.println(parser.symbolTable.getInteger(varName, dim));
                }else{
                    System.out.println(parser.symbolTable.getDouble(varName, dim));
                }


            }else if (instrName.equals("GOTO")) {
                Integer line = parser.labelTable.get(instrArgs.get(0));
                if (parser.debug_level>=2)                 
                    System.out.println(" LABEL: "+instrArgs.get(0)+" -> LINE: "+line);
                ip = line.intValue();

            }else if (instrName.equals("GOTOT")) {
                Integer line = parser.labelTable.get(instrArgs.get(0));
                if ( (lastResult.getInteger()).intValue()!=0) {
                    ip = line.intValue();
                }
                if (parser.debug_level>=2)                 
                    System.out.println(" LABEL: "+instrArgs.get(0)+" -> LINE: "+line);


            }else if (instrName.equals("GOTOF")) {
                Integer line = parser.labelTable.get(instrArgs.get(0));
                if ( (lastResult.getInteger()).intValue()==0) {
                    ip = line.intValue();
                }
                if (parser.debug_level>=2)                 
                    System.out.println(" LABEL: "+instrArgs.get(0)+" -> LINE: "+line);

            }else if (instrName.equals("END")) {
                keepOnRunning = false;
            }

        }while(keepOnRunning);

    }



    
    private Result execEVAL(List argList){
        Stack<Object> stack = new Stack<Object>();
        Object op1, op2;
        Object result;
        String el;

        Iterator itr = argList.iterator();
         
        while(itr.hasNext()){
            el = (String)itr.next();
        
 
            //System.out.println(el);
                
            if (el.contentEquals("!")){
                op1 = stack.pop();
                    
                if(op1 instanceof Integer){
                    int oper1 = ((Integer)op1).intValue();

                    if (oper1==0) stack.push(new Integer(1));
                    else stack.push(new Integer(0));

                }else{
                    float oper1 = ((Double)op1).floatValue();

                    if (oper1==0) stack.push(new Integer(1));
                    else stack.push(new Integer(0));

                }
                    
                    
   
            }else if (el.contentEquals("+") || el.contentEquals("-")
                      || el.contentEquals("*") || el.contentEquals("/")
                      || el.contentEquals("&") || el.contentEquals("|")
                      || el.contentEquals("==") || el.contentEquals(">")
                      || el.contentEquals("<") || el.contentEquals(">=")
                      || el.contentEquals("<=")){

                op2 = stack.pop();
                op1 = stack.pop();

                if(op1 instanceof Integer && op2 instanceof Integer){
                    int oper1 = ((Integer)op1).intValue();
                    int oper2 = ((Integer)op2).intValue();
                        
                    if (el.contentEquals("+")){
                        stack.push(new Integer(oper1+oper2));
                    }else if (el.contentEquals("-")){
                        stack.push(new Integer(oper1-oper2));
                    }else if (el.contentEquals("*")){
                        stack.push(new Integer(oper1*oper2));
                    }else if(el.contentEquals("/")){
                        stack.push(new Integer(oper1/oper2));
                    }else if(el.contentEquals("==")){
                        if (oper1==oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals(">")){
                        if (oper1>oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals("<")){
                        if (oper1<oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals(">=")){
                        if (oper1>=oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals("<=")){
                        if (oper1<=oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals("&")){
                        if (oper1==1 && oper2==1){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals("|")){
                        if (oper1==1 || oper2==1){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }
                        

                        
                }else{
                    double oper1;
                    double oper2;

                    if (op1 instanceof Integer){
                        oper1 = ((Integer)op1).doubleValue();
                    }else{
                        oper1 = ((Double)op1).doubleValue();
                    }
                    if (op2 instanceof Integer){
                        oper2 = ((Integer)op2).doubleValue();
                    }else{
                        oper2 = ((Double)op2).doubleValue();
                    }


                    if (el.contentEquals("+")){
                        stack.push(new Double(oper1+oper2));
                    }else if (el.contentEquals("-")){
                        stack.push(new Double(oper1-oper2));
                    }else if (el.contentEquals("*")){
                        stack.push(new Double(oper1*oper2));
                    }else if(el.contentEquals("/")){
                        stack.push(new Double(oper1/oper2));
                    }else if(el.contentEquals("==")){
                        if (oper1==oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals(">")){
                        if (oper1>oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals("<")){
                        if (oper1<oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals(">=")){
                        if (oper1>=oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals("<=")){
                        if (oper1<=oper2){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals("&")){
                        if (oper1==1 && oper2==1){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }else if(el.contentEquals("|")){
                        if (oper1==1 || oper2==1){
                            stack.push(new Integer(1));
                        }else{
                            stack.push(new Integer(0));
                        }
                    }
                        

                }
            }else if (isInteger(el)){
                stack.push(new Integer(el));
            }else if (isDouble(el)){
                stack.push(new Double(el));
            }else {
                String varName = getVarNameFromArray(el);
                int dim = getDimFromArray(el);

                if (parser.symbolTable.isInteger(varName)) {
                    stack.push(parser.symbolTable.getInteger(varName, dim));
                }else{
                    stack.push(parser.symbolTable.getDouble(varName, dim));
                }
            }

        }
        
        result = stack.pop();
        if (result instanceof Integer){
            return new Result((Integer)result);
        }else{
            return new Result((Double)result);
        }
    }    
}

